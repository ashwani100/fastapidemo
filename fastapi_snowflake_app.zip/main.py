from fastapi import FastAPI, HTTPException
from db import get_snowflake_connection

app = FastAPI()

@app.get("/data")
def get_data():
    try:
        conn = get_snowflake_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM YOUR_TABLE LIMIT 10")

        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
        result = [dict(zip(columns, row)) for row in rows]

        cursor.close()
        conn.close()
        return {"data": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
