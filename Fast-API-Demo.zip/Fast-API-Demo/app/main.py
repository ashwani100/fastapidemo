from fastapi import FastAPI

app = FastAPI(
    title="FastAPI ECS Demo",
    version="0.1.0",
    description="A minimal FastAPI service on ECS/Fargate"
)

@app.get("/")
async def root():
    return {"message": "Hello, FastAPI on ECS!"}