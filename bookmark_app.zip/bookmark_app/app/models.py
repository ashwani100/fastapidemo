
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class BookmarkData(BaseModel):
    user_id: str
    site_id: str
    site_name: str
    is_bookmark: Optional[bool] = False
    is_pin: Optional[bool] = False
    last_search_date: datetime

class ConversationData(BaseModel):
    user_id: str
    site_id: str
    question_text: str
    answer_text: str
    is_thumsup: Optional[bool] = False
    last_search_date: datetime
