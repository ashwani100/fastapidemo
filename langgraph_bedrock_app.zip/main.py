from fastapi import FastAPI
from pydantic import BaseModel
from langgraph.graph import StateGraph, END
import os, json, boto3

# Load KPI data
with open("kpis.json", "r") as f:
    kpis = json.load(f)

# Setup Bedrock client
bedrock = boto3.client("bedrock-runtime", region_name=os.getenv("AWS_REGION"))

app = FastAPI()

# Request schema
class Question(BaseModel):
    query: str

# --------- Child: Prepopulated Graph ---------

def classify_kpi_category(state):
    query = state["query"].lower()
    for key in kpis:
        if key.lower() in query:
            state["kpi_key"] = key
            return state
    state["kpi_key"] = None
    return state

def fetch_kpi_response(state):
    key = state["kpi_key"]
    state["response"] = kpis.get(key, "KPI category not found.")
    return state

pre_graph = StateGraph(input_type=dict)
pre_graph.add_node("classify_kpi", classify_kpi_category)
pre_graph.add_node("fetch_kpi", fetch_kpi_response)
pre_graph.set_entry_point("classify_kpi")
pre_graph.add_edge("classify_kpi", "fetch_kpi")
pre_graph.add_edge("fetch_kpi", END)
prepopulated_graph = pre_graph.compile()

# --------- Child: Custom Graph ---------

def call_llm(state):
    prompt = f"\n\nHuman: {state['query']}\n\nAssistant:"
    response = bedrock.invoke_model(
        modelId=os.getenv("BEDROCK_MODEL_ID"),
        contentType="application/json",
        accept="application/json",
        body=json.dumps({
            "prompt": prompt,
            "max_tokens_to_sample": 300,
            "temperature": 0.7,
            "top_k": 250,
            "top_p": 1
        })
    )
    result = json.loads(response['body'].read())
    state["response"] = result.get("completion", "No response from model.")
    return state

custom_graph = StateGraph(input_type=dict)
custom_graph.add_node("call_llm", call_llm)
custom_graph.set_entry_point("call_llm")
custom_graph.add_edge("call_llm", END)
custom_question_graph = custom_graph.compile()

# --------- Parent Graph ---------

def classify_query_type(state):
    q = state["query"].lower()
    for kpi in kpis:
        if kpi.lower() in q:
            state["query_type"] = "prepopulated"
            return state
    state["query_type"] = "custom"
    return state

def route_child(state):
    if state["query_type"] == "prepopulated":
        return "child_pre"
    else:
        return "child_custom"

parent = StateGraph(input_type=dict)
parent.add_node("classify", classify_query_type)
parent.add_node("child_pre", prepopulated_graph)
parent.add_node("child_custom", custom_question_graph)
parent.set_entry_point("classify")
parent.add_conditional_edges("classify", route_child)
parent.add_edge("child_pre", END)
parent.add_edge("child_custom", END)
parent_graph = parent.compile()

@app.post("/ask")
async def ask_question(q: Question):
    result = parent_graph.invoke({"query": q.query})
    return {"response": result["response"]}
