
import boto3
from boto3.dynamodb.conditions import Key
import os

dynamodb = boto3.resource(
    'dynamodb',
    region_name='us-east-1',
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
)

def create_table_if_not_exists(table_name, key_schema, attribute_definitions):
    try:
        table = dynamodb.Table(table_name)
        table.load()
    except:
        table = dynamodb.create_table(
            TableName=table_name,
            KeySchema=key_schema,
            AttributeDefinitions=attribute_definitions,
            BillingMode='PAY_PER_REQUEST'
        )
        table.wait_until_exists()
    return table

def put_item(table_name, item: dict):
    table = dynamodb.Table(table_name)
    table.put_item(Item=item)

def get_user_data(table_name, user_id):
    table = dynamodb.Table(table_name)
    response = table.query(
        KeyConditionExpression=Key("user_id").eq(user_id),
        ScanIndexForward=False
    )
    return response.get("Items", [])
